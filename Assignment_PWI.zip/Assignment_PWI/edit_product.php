<?php
include('config.php');

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    $sql = "UPDATE produk SET nama_produk = ?, harga = ?, deskripsi = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $nama_produk, $harga, $deskripsi, $id);
    $stmt->execute();

    header('Location: index.php');
    exit;
}

// Ambil data produk berdasarkan ID
$sql = "SELECT * FROM produk WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Produk</h1>
        <form action="edit_product.php?id=<?php echo $product['id']; ?>" method="POST">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" name="nama_produk" id="nama_produk" value="<?php echo htmlspecialchars($product['nama_produk']); ?>" required>

            <label for="harga">Harga</label>
            <input type="number" name="harga" id="harga" value="<?php echo $product['harga']; ?>" required>

            <label for="deskripsi">Deskripsi</label>
            <textarea name="deskripsi" id="deskripsi" required><?php echo htmlspecialchars($product['deskripsi']); ?></textarea>

            <button type="submit" class="btn">Update</button>
        </form>
        <a href="index.php" class="btn">Kembali</a>
    </div>
</body>
</html>

<?php $conn->close(); ?>
